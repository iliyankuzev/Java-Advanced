package DefiningClasses.Exercise.catLady;

public class Main {
    public static void main(String[] args) {
        Cat tobi = new Cat("Tobi", 12);
        tobi.meow();
        Cat puhcho = new Cat("Pucho", 1);
        puhcho.meow();
    }
}
