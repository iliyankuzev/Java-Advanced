package DefiningClasses.Exercise.carSalesman;

import java.util.*;

public class carMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        Map<String, carEngine> engineMap = new HashMap<>();

        while (n-- > 0){
            String[]input = scanner.nextLine().split("\\s+");

            //car spec
            String model = input[0];
            int power = Integer.parseInt(input[1]);
            String displacement = "n/a";
            String efficiency = "n/a";

            if (input.length>2){
                try{
                    int t = Integer.parseInt(input[2]);
                    displacement = input[2];

                    if (input.length > 3){
                        efficiency = input[3];
                    }else{
                        efficiency = "n/a";
                    }
                }catch (Exception e){
                    efficiency = input[2];
                    displacement = "n/a";
                }
            }
            carEngine engine = new carEngine(model, power, displacement, efficiency);
            engineMap.put(model, engine);
        }

        List<carCar> cars = new ArrayList<>();
        int m = Integer.parseInt(scanner.nextLine());

        while (m-- > 0){
            String[]input = scanner.nextLine().split("\\s+");

            //car spec
            String model = input[0];
            carEngine engine = engineMap.get(input[1]);
            String weight = "n/a";
            String color = "n/a";

            if (input.length > 2){
                try{
                    int t = Integer.parseInt(input[2]);
                    weight = input[2];
                    if (input.length>3){
                        color = input[3];
                    }
                }catch (Exception e){
                    color = input[2];
                }
            }
            carCar car = new carCar(model, engine,weight,color);
            cars.add(car);
        }
        cars.forEach(System.out::print);
    }
}
